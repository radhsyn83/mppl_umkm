package xyz.radhzyn83.mpplumkm.domain.presenter

/**
 * Created by FathurRadhy on 3/15/2018.
 */
interface ProdukPresenter {
    fun doLoadProduk(start: String)
}