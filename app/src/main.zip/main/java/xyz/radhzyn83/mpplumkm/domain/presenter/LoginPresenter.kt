package com.kotlin.model

/**
 * Created by FathurRadhy on 1/29/2018.
 */
interface LoginPresenter {
    fun doLogin(email : String, password : String);
}